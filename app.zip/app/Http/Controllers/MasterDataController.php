<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;

class MasterDataController extends Controller
{
    public function saveexamtype(Request $request)
    {

        $this->validate($request, [
            'examtype' => 'required',
        ]);

        $examType = $request->input('examtype');

        DB::table('examtypes')->insert(
            [
                'examtype' => $examType,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/examtypes')->with('response', '' . $examType);
    }

    public function manageexamtype($id)
    {

        $examtypedata    = DB::table('examtypes')->where('id', '=', $id)->get();
        $dataset = [
            'examtypedata' => $examtypedata,
        ];

        return view('pages.manageexamtype')->with('dataset', $dataset);
    }

    public function editexamtype(Request $request)
    {
        $this->validate($request, [
            'examtype' => 'required',
        ]);

        $examTypeId = $request->input('examtypeid');
        $examType = $request->input('examtype');

        DB::table('examtypes')
            ->where('id', $examTypeId)
            ->update(['examtype' => $examType]);

        return redirect('/examtypes')->with('edit_response', '' . $examType);
    }

    public function removeexamtype($id)
    {

        DB::table('examtypes')->where('id', '=', $id)->delete();
        return redirect('/examtypes')->with('delete_response', '' . $id);
    }

    public function savesubject(Request $request)
    {
        $this->validate($request, [
            'subject' => 'required',
        ]);

        $subject = $request->input('subject');

        DB::table('subjects')->insert(
            [
                'subject' => $subject,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/subjects')->with('response', '' . $subject);
    }

    public function managesubject($id)
    {

        $examtypedata    = DB::table('subjects')->where('id', '=', $id)->get();
        $dataset = [
            'subjectdata' => $examtypedata,
        ];

        return view('pages.managesubject')->with('dataset', $dataset);
    }

    public function editsubject(Request $request)
    {
        $this->validate($request, [
            'subject' => 'required',
        ]);

        $subjectId = $request->input('subjectid');
        $subject = $request->input('subject');

        DB::table('subjects')
            ->where('id', $subjectId)
            ->update(['subject' => $subject]);

        return redirect('/subjects')->with('edit_response', '' . $subject);
    }

    public function removesubject($id)
    {

        DB::table('subjects')->where('id', '=', $id)->delete();
        return redirect('/subjects')->with('delete_response', '' . $id);
    }

    public function savecategory(Request $request)
    {
        $this->validate($request, [
            'category' => 'required',
        ]);

        $category = $request->input('category');

        DB::table('categories')->insert(
            [
                'category' => $category,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/categories')->with('response', '' . $category);
    }

    public function managecategory($id)
    {

        $categorydata    = DB::table('categories')->where('id', '=', $id)->get();
        $dataset = [
            'categorydata' => $categorydata,
        ];

        return view('pages.managecategory')->with('dataset', $dataset);
    }

    public function editcategory(Request $request)
    {
        $this->validate($request, [
            'category' => 'required',
        ]);

        $categoryId = $request->input('categoryid');
        $category = $request->input('category');

        DB::table('categories')
            ->where('id', $categoryId)
            ->update(['category' => $category]);

        return redirect('/categories')->with('edit_response', '' . $category);
    }


    public function removecategory($id)
    {

        DB::table('categories')->where('id', '=', $id)->delete();
        return redirect('/categories')->with('delete_response', '' . $id);
    }

    public function savesubcategory(Request $request)
    {
        $this->validate($request, [
            'subcategory' => 'required',
        ]);

        $subcategory = $request->input('subcategory');
        $parentcategoryValue = $request->input('parentcategory');
        $splitlist = explode('-', $parentcategoryValue);
        $parentcategoryid = $splitlist[0];
        $parentcategoryName = $splitlist[1];

        DB::table('subcategories')->insert(
            [
                'subcategory' => $subcategory,
                'parentcategoryid' => $parentcategoryid,
                'parentcategory' => $parentcategoryName,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/subcategories')->with('response', '' . $subcategory . ' under ' . $parentcategoryName);
    }

    public function managesubcategory($id)
    {

        $subcategorydata    = DB::table('subcategories')->where('id', '=', $id)->get();
        $parentcategorydata    = DB::table('categories')->get();
        $dataset = [
            'subcategorydata' => $subcategorydata,
            'parentcategorydata' => $parentcategorydata,
        ];

        return view('pages.managesubcategory')->with('dataset', $dataset);
    }

    public function editsubcategory(Request $request)
    {
        $this->validate($request, [
            'subcategory' => 'required',
        ]);

        $subcategoryId = $request->input('subcategoryid');
        $subcategory = $request->input('subcategory');
        $parentcategoryValue = $request->input('parentcategory');
        $splitlist = explode('-', $parentcategoryValue);
        $parentcategoryid = $splitlist[0];
        $parentcategoryName = $splitlist[1];


        DB::table('subcategories')
            ->where('id', $subcategoryId)
            ->update([
                'subcategory' => $subcategory,
                'parentcategoryid' => $parentcategoryid,
                'parentcategory' => $parentcategoryName,
            ]);

        return redirect('/subcategories')->with('edit_response', '' . $subcategory);
    }

    public function removesubcategory($id)
    {

        DB::table('subcategories')->where('id', '=', $id)->delete();
        return redirect('/subcategories')->with('delete_response', '' . $id);
    }

    public function savelevel(Request $request)
    {
        $this->validate($request, [
            'level' => 'required',
        ]);

        $level = $request->input('level');

        DB::table('levels')->insert(
            [
                'level' => $level,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/levels')->with('response', '' . $level);
    }

    public function managelevel($id)
    {

        $leveldata    = DB::table('levels')->where('id', '=', $id)->get();
        $dataset = [
            'leveldata' => $leveldata,
        ];

        return view('pages.managelevel')->with('dataset', $dataset);
    }

    public function editlevel(Request $request)
    {
        $this->validate($request, [
            'level' => 'required',
        ]);

        $levelId = $request->input('levelid');
        $level = $request->input('level');

        DB::table('levels')
            ->where('id', $levelId)
            ->update(['level' => $level]);

        return redirect('/levels')->with('edit_response', '' . $level);
    }

    public function removelevel($id)
    {

        DB::table('levels')->where('id', '=', $id)->delete();
        return redirect('/levels')->with('delete_response', '' . $id);
    }

    public function savegrade(Request $request)
    {
        $this->validate($request, [
            'grade' => 'required',
        ]);

        $level = $request->input('grade');

        DB::table('grades')->insert(
            [
                'grade' => $level,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/grades')->with('response', '' . $level);
    }

    public function managegrade($id)
    {

        $gradedata    = DB::table('grades')->where('id', '=', $id)->get();
        $dataset = [
            'gradedata' => $gradedata,
        ];

        return view('pages.managegrade')->with('dataset', $dataset);
    }

    public function editgrade(Request $request)
    {
        $this->validate($request, [
            'grade' => 'required',
        ]);

        $gradeId = $request->input('gradeid');
        $grade = $request->input('grade');

        DB::table('grades')
            ->where('id', $gradeId)
            ->update(['grade' => $grade]);

        return redirect('/grades')->with('edit_response', '' . $grade);
    }

    public function removegrade($id)
    {

        DB::table('grades')->where('id', '=', $id)->delete();
        return redirect('/grades')->with('delete_response', '' . $id);
    }

    public function getsubcategorydata($id)
    {

        $subcategorydata = DB::table('subcategories')->where('parentcategoryid', '=', $id)->get();
        return $subcategorydata;
    }

    public function getexamdataforsubject($id)
    {

        $papertemplatesdata = DB::table('papertemplates')->where('subjectid', '=', $id)->get();
        return $papertemplatesdata;
    }

    public function savepromotion(Request $request)
    {

        $promotype = $request->input('promotype');
        $promoname = $request->input('promoname');
        $promodescription = $request->input('promodescription');
        $papercount = $request->input('papercount');
        $price = $request->input('price');

        DB::table('promotions')->insert(
            [
                'promotype' => $promotype,
                'promoname' => $promoname,
                'promodescription' => $promodescription,
                'paperscount' => $papercount,
                'price' => $price,
                'status' => 'A',
                'user' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/promotionsmanager')->with('addpromo', '' . $promoname);
    }

    public function saveuserrole(Request $request)
    {
        $this->validate($request, [
            'userrole' => 'required',
        ]);

        $userrole = $request->input('userrole');

        DB::table('userroles')->insert(
            [
                'userrole' => $userrole,
                'status' => 'A',
                'userid' => 'NA',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        return redirect('/userroles')->with('response', '' . $userrole);
    }

    public function managedataentryop($id)
    {
        $usersdata = DB::table('users')->where('id', '=', $id)->get();
        $dataset = [
            'usersdata' => $usersdata,

        ];
        return view('pages.managedataentryop')->with('dataset', $dataset);
    }

    public function editdataentryallowance(Request $request)
    {

        $this->validate($request, [
            'allowance' => 'required',
        ]);

        $allowance = $request->input('allowance');
        $dataentryid = $request->input('dataentryid');

        DB::table('users')
            ->where('id', $dataentryid)
            ->update(['allowance' => $allowance]);

        return redirect('/dataentrylist')->with('edit_response', '' . $allowance);
    }

    public function registeruser(Request $request)
    {

        $this->validate($request, [
            'name' => 'required|min:3|max:50',
            'email' => 'email',
            'password' => 'min:6|required_with:password_confirmation|same:password_confirmation',
            'password_confirmation' => 'min:6'
        ]);

        $username = $request->input('name');
        $email = $request->input('email');
        $role = $request->input('role');
        $password = $request->input('password');
        $language1 = $request->input('language1');

        User::create([
            'name' =>  $username,
            'email' => $email,
            'role' => $role,
            'language1' => $language1,
            'password' => Hash::make($password),
        ]);

        return redirect('/userlist')->with('edit_response', '' . $username);
    }

    public function registerstudent(Request $request)
    {

        $this->validate($request, [
            'name' => 'required|min:3|max:50',
            'studentname' => 'required|min:3|max:50',
            'parentname' => 'required|min:3|max:50',
            'address' => 'required|min:3|max:50',
            'telephone' => 'required|min:3|max:50',
            'email' => 'email',
            'password' => 'min:6|required_with:password_confirmation|same:password_confirmation',
            'password_confirmation' => 'min:6'
        ]);

        $studentname = $request->input('studentname');
        $parentname = $request->input('parentname');
        $address = $request->input('address');
        $telephone = $request->input('telephone');
        $email = $request->input('email');
        $mobile = $request->input('mobile');
        $examentrycount = 0;
        $paymethod = $request->input('paymethod');


        $username = $request->input('name');
        $email = $request->input('email');
        $role = 'Student';
        $password = $request->input('password');

        User::create([
            'name' =>  $username,
            'email' => $email,
            'role' => $role,
            'password' => Hash::make($password),
        ]);

        $mailhash = rand();

        $stdid = DB::table('students')->insertGetId(
            [
                'studentname' => $studentname,
                'parentname' => $parentname,
                'address' => $address,
                'telephone' => $telephone,
                'mobile' => $mobile,
                'email' => $email,
                'exams' => $examentrycount,
                'paymethod' => $paymethod,
                'mailconfirmed' => '0',
                'mailhash' => $mailhash,
                'status' => '1',
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );

        $data = array(
            'mailhash' => $stdid . '-' . $mailhash,

        );

        Mail::to($email)->send(new WelcomeMail($data));

        return view('pages.studentmailsentscreen')->with('email', $email);
    }

    public function emailactivation($hashcode)
    {
        $hlist = explode("-", $hashcode);
        $stdid = $hlist[0];
        $hashval = $hlist[1];
        $usersdata = DB::table('students')->where([
            'id' => $stdid,
            'mailhash' => $hashval,
            'mailconfirmed' => '0',
        ])->get();

        if (count($usersdata) > 0) {
            $affected = DB::table('students')
                ->where([
                    'id' => $stdid,
                    'mailhash' => $hashval,
                    'mailconfirmed' => '0',
                ])->update(['mailconfirmed' => 1]);
            return view('pages.studentlinkvalid');
        } else {
            return view('pages.studentlinkinvalid');
        }
    }
}
