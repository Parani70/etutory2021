<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PaperTemplateController extends Controller
{
    public function savepapertemplate(Request $request){

        $coursename = $request->input('coursename');
        $numberofquestion = $request->input('noofquestions');
        $questionentrycount = $request->input('questionentrycount');
        $durationhr = $request->input('durationhr');
        $durationmin = $request->input('durationmin');

       if($durationhr == ''){
        $durationhr=0;
       }

       if($durationmin == ''){
        $durationmin=0;
       }
        
        $exploded_list = explode('-', $request->input('subject'));
        $subjectid = $exploded_list[0];
        $subjectname = $exploded_list[1];
        $exploded_list = explode('-', $request->input('grade'));
        $gradeid = $exploded_list[0];
        $gradename = $exploded_list[1];
        

        DB::table('papertemplates')->insert(
            [
                'coursename' => $coursename,
                'subjectid' => $subjectid,
                'subjectname' => $subjectname,
                'gradeid' => $gradeid,
                'gradename' => $gradename,
                'numberofquestion' => $numberofquestion,
                'durationhour' => $durationhr,
                'durationminute' => $durationmin,
                'created_at' => NOW(),
                'updated_at' => NOW(),                
            ]
        );

        $templateid = DB::table('papertemplates')->max('id');


        $i=1;
        while($questionentrycount > $i){

            $exploded_list = explode('-', $request->input('category'.$i));
            $categoryid = $exploded_list[0];
            $categoryname = $exploded_list[1];
            $exploded_list = explode('-', $request->input('subcategory'.$i));
            $subcategoryid = $exploded_list[0];
            $subcategoryname = $exploded_list[1];
            $exploded_list = explode('-', $request->input('level'.$i));
            $levelid = $exploded_list[0];
            $levelname = $exploded_list[1];

            $qstype = $request->input('qstype'.$i);
            $qscount = $request->input('qscount'.$i);

            DB::table('papertemplatesdata')->insert(
                [
                    'templateid' => $templateid,
                    'categoryid' => $categoryid,
                    'categoryname' => $categoryname,
                    'subcategoryid' => $subcategoryid,
                    'subcategoryname' => $subcategoryname,
                    'levelid' => $levelid,
                    'levelname' => $levelname,
                    'qstype' => $qstype,
                    'qscount' => $qscount,
                    'created_at' => NOW(),
                    'updated_at' => NOW(),                
                ]
            );


            $i++;
        }

        $papertemplates    = DB::table('papertemplates')->get();
        $examtypedata    = DB::table('examtypes')->get();
        $categorydata    = DB::table('categories')->get();
        $subcategorydata    = DB::table('subcategories')->where('parentcategoryid', '=', $categorydata[0]->id)->get();
        $subjectdata    = DB::table('subjects')->get();
        $gradedata    = DB::table('grades')->get();
        $leveldata   = DB::table('levels')->get();

        $dataset = [
            'papertemplates' => $papertemplates,
            'examtypedata' => $examtypedata,
            'categorydata' => $categorydata,
            'subcategorydata' => $subcategorydata,
            'subjectdata' => $subjectdata,
            'gradedata' => $gradedata,
            'leveldata' => $leveldata,
        ];

        return view('pages.examtemplates')->with('dataset',$dataset);

    }
}
