<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PricingController extends Controller
{
    public function savepricing(Request $request){


        $grade = $request->input('grade');
        $sarray = explode('-',$grade);
        $gradeid = $sarray[0];
        $gradename = $sarray[1];

        $subject = $request->input('subject');
        $sarray = explode('-',$subject);
        $subjectid = $sarray[0];
        $subjectname = $sarray[1];

        $price = $request->input('price');
        $userid = Auth::user()->id;

        DB::table('exampricing')->insert(
            [
                'gradeid' => $gradeid,
                'gradename' => $gradename,
                'subjectid' => $subjectid,
                'subjectname' => $subjectname,
                'price' => $price,
                'user' => $userid,               
                'created_at' => NOW(),
                'updated_at' => NOW(),                
            ]
        );
        return redirect('/pricingmanager')->with('response', '' . $gradename.' - '.$subjectname);
        

    }

    public function buynewexam(Request $request){

        $subject = $request->input('subject');
        $sarray = explode('-',$subject);
        $subjectid = $sarray[0];
        $subjectname = $sarray[1];
        $examid = $request->input('examlist');

        $examdata   = DB::table('papertemplates')->where('id', '=', $examid)->get();
        $examgradeid =  $examdata[0]->gradeid;
        $examgradename =  $examdata[0]->gradename;
        $examname =  $examdata[0]->coursename;

        $pricingdata   = DB::table('exampricing')->where([
            'subjectid' => $subjectid,
            'gradeid' => $examgradeid,
        ])->get();

        $price = $pricingdata[0]->price;

        $dataset = [
            'examid' => $examid,
            'examname' => $examname,
            'subjectid' => $subjectid,
            'subjectname' => $subjectname,
            'gradeid' => $examgradeid,
            'gradename' => $examgradename,
            'price' => $price,
        ];

        return view('pages.exambuyscreen')->with('dataset', $dataset);
    }

    public function proceedtoexampay(Request $request){
        $examid = $request->input('examid');
        $price = $request->input('examprice');
        $type = $request->input('producttype');

        $dataset = [
            'examid' => $examid,
            'price' => $price,
            'type' => $type,
        ];

        return view('pages.paymentselect')->with('dataset', $dataset);

    }

    public function saveexampayment(Request $request){
        $examid = $request->input('examid');
        $price = $request->input('examprice');
        $type = $request->input('producttype');
        $paymethod = $request->input('paymethod');

        $examdata = DB::table('papertemplates')->where([
            'id' => $examid,
        ])->get();

        $examname = $examdata[0]->coursename;
        $grade = $examdata[0]->gradeid;
        $subject = $examdata[0]->subjectid;
        $gradename = $examdata[0]->gradename;
        $subjectname = $examdata[0]->subjectname;
        $image ='N';
        if($paymethod == "bank"){
            if ($request->hasFile('depositimage')) {
                
                $imageFile = $request->file('depositimage')->getClientOriginalName();
                $imageFileName = pathinfo($imageFile, PATHINFO_FILENAME);
                $imageFileExtention = $request->file('depositimage')->getClientOriginalExtension();
    
                $fileNameToStore = $imageFileName . '_' . time() . '.' . $imageFileExtention;
                // $imageFileName = 'question_mcq'.$imageFile.getClientOrginalExtension();
                $path = $request->file('depositimage')->storeAs('public/deposit_images', $fileNameToStore);
                $image = $fileNameToStore;
            }
        }

        $userEmail = Auth::user()->email;

        //get student data
        $studentdata = DB::table('students')->where([
            'email' => $userEmail,
        ])->get();

        $studentid = $studentdata[0]->id;
        $studentname = $studentdata[0]->studentname;

    
        DB::table('studenttransactions')->insert(
            [
                'studentid' => $studentid,
                'studentname' => $studentname,
                'email' => $userEmail,
                'type' => $type,
                'productid' => $examid,
                'productname' => $examname,
                'grade' => $grade,
                'subjectname' => $subjectname,
                'subject' => $subject,
                'price' => $price,
                'paymethod' => $paymethod,
                'paystatus' => '0',
                'approvedbyid' => 'N',
                'approvedbyname' => 'N',
                'approvedbydate' => 'N',
                'status' => '1',
                'image' => $image,                
                'created_at' => NOW(),
                'updated_at' => NOW(),
            ]
        );
        

        $dataset = [
            'examid' => $examid,
            'examname' => $examname,
            'price' => $price,
            'subject' => $subjectname,
            'grade' => $gradename,
        ];

        return view('pages.paymentreceipt')->with('dataset', $dataset);

    }
}
