<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ExamController extends Controller
{
    public function startexam(Request $request)
    {

        $examid = $request->input('examid');
        $examdata = DB::table('papertemplates')->where('id', '=', $examid)->get();
        $examsubdata = DB::table('papertemplatesdata')->where('templateid', '=', $examid)->get();

        $subject = $examdata[0]->subjectid;
        $grade = $examdata[0]->gradeid;
        $duration_hrs = $examdata[0]->durationhour;
        $duration_mns = $examdata[0]->durationminute;

        $questioncore = [];
        $c = 0;
        foreach ($examsubdata as $examsub) {
            $category = $examsub->categoryid;
            $subcategory = $examsub->subcategoryid;
            $level = $examsub->levelid;
            $qstype = $examsub->qstype;
            $qscount = $examsub->qscount;

            $questionrawdata = DB::table('questionsmain')->where([
                'qstype' => $qstype,
                'categoryid' => $category,
                'subcategoryid' => $subcategory,
                'subjectid' => $subject,
                'gradeid' => $grade,
                'levelid' => $level,
                'status' => '1',
            ])->limit($qscount)->inRandomOrder()->get();

            foreach ($questionrawdata as $question) {

                $questioncore[$c][0] = [
                    'type' => $qstype,
                    'number' => $question->id,
                ];

                $c++;
            }
        }

        $dataset = [
            'examid' => $examid,
            'examdata' => $examdata,
            'examsubdata' => $examsubdata,
            'questioncore' => $questioncore,
            'c' => $c,
            'duration_hours' => $duration_hrs,
            'duration_minutes' => $duration_mns,
        ];
        return view('pages.examstart')->with('dataset', $dataset);
    }
}
